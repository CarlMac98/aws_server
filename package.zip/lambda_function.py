def lambda_handler(event, context):
    import json
    from pydub import AudioSegment
    import boto3
    import settings as s
    
    s3 = boto3.client('s3')
    s3r = boto3.resource('s3')

    bucket = event['Records'][0]['s3']['bucket']['name']
    src = event['Records'][0]['s3']['object']['key']
    
    tmpdir = "/tmp/" + src
    s3r.Bucket(bucket).Object(src).download_file(tmpdir)
    
    src_format = src.split(".")[2]
    dst_format = src.split(".")[0]
    DBucket = s.OUTPUT
    
    res = AudioSegment.from_file(tmpdir, format = src_format)
    final = "/tmp/"+ src.split(".")[0] + dst_format
    res.export(final, format = dst_format)
    s3.upload_file(final, DBucket, src.split(".")[1] + "." + dst_format)

    return {
        'statusCode': 200,
        'body': json.dumps("Success!")
    }
