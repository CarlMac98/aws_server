UPDOWN = "otherbck"
TRIGGER = "tobeconvertedsoon"
OUTPUT = "convlambdaresults"
TRANSCRIBE = "transcribingstuff"
